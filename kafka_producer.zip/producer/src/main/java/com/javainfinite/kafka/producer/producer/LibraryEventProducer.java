package com.javainfinite.kafka.producer.producer;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.javainfinite.kafka.producer.model.LibraryEvent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Component;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;


@Component
@Slf4j
public class LibraryEventProducer {


    private KafkaTemplate<Integer, String> kafkaTemplate;

    private ObjectMapper mapper;

    public LibraryEventProducer(KafkaTemplate<Integer, String> kafkaTemplate, ObjectMapper mapper) {
        this.kafkaTemplate = kafkaTemplate;
        this.mapper = mapper;
    }

    public void sendLibraryEvent(LibraryEvent libraryEvent) throws JsonProcessingException {

        Integer key = libraryEvent.getLibraryEventId();

        String value = mapper.writeValueAsString(libraryEvent);
        ListenableFuture<SendResult<Integer, String>> future = kafkaTemplate.sendDefault(key, value);
        future.addCallback(new ListenableFutureCallback<SendResult<Integer, String>>() {
            @Override
            public void onFailure(Throwable ex) {
                handleFailure(key, value, ex);
            }

            @Override
            public void onSuccess(SendResult<Integer, String> result) {
                handleSuccess(result, key, value);
            }
        });
    }

    public void sendLibraryEventApproach2(LibraryEvent libraryEvent) throws JsonProcessingException{

        Integer key = libraryEvent.getLibraryEventId();

        String value = mapper.writeValueAsString(libraryEvent);
        ListenableFuture<SendResult<Integer, String>> future = kafkaTemplate.send("library-events",key, value);
        future.addCallback(new ListenableFutureCallback<SendResult<Integer, String>>() {
            @Override
            public void onFailure(Throwable ex) {
                handleFailure(key, value, ex);
            }

            @Override
            public void onSuccess(SendResult<Integer, String> result) {
                handleSuccess(result, key, value);
            }
        });

    }


    private void handleSuccess(SendResult<Integer, String> result, Integer key, String value) {
        log.info("Message successfully produced for the key: {} and value: {} in partition", key, value, result.getRecordMetadata().partition());
    }

    private void handleFailure(Integer key, String value, Throwable ex) {
        log.error("Exception thrown : {} for key: {} and value: {}", ex.getMessage(), key, value);
        try {
            throw ex;
        } catch (Throwable e) {
            e.printStackTrace();
        }
    }


}
